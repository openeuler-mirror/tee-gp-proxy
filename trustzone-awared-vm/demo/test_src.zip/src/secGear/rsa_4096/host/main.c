/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2020. All rights reserved.
 * secGear is licensed under the Mulan PSL v2.
 * You can use this software according to the terms and conditions of the Mulan PSL v2.
 * You may obtain a copy of Mulan PSL v2 at:
 *     http://license.coscl.org.cn/MulanPSL2
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY OR FIT FOR A PARTICULAR
 * PURPOSE.
 * See the Mulan PSL v2 for more details.
 */

#include <stdio.h>
#include <unistd.h>
#include <linux/limits.h>
#include <sys/time.h>
#include <string.h>
#include <pthread.h>
#include "enclave.h"
#include "secgear_uswitchless.h"
#include "secgear_shared_memory.h"

#include "switchless_u.h"

#define ICOUNT 100
#define THREAD_COUNT    4
//#define TEEC_DEBUG

#define RSA_KEY_SIZE                256    // 2048bits
#define RSA_MASSAGE_SIZE            100    // see rsa-demoTA.c, massage size has some limitation.
#define RSA_KEY_1                   1
#define RSA_ALG_OAEP_SHA512         1      // use TEE_ALG_RSAES_PKCS1_OAEP_MGF1_SHA512 mode for crypto
#define RSA_ALG_PSS_SHA256          2      // use TEE_ALG_RSASSA_PKCS1_PSS_MGF1_SHA256 mode for sign
#define RSA_INPUT_ERROR_PARAMETER   0x10000001
#define PRINTF_SIZE                 32

#ifdef TEEC_DEBUG
void DumpBuff(const char *buffer, size_t bufLen)
{
    size_t i;
    if (buffer == NULL || bufLen == 0) {
        return;
    }

    printf("\n--------------------------------------------------\n");
    printf("bufLen = %zu\n", bufLen);
    for (i = 0; i < bufLen; i++) {
        if (i % PRINTF_SIZE == 0) {
            printf("\n");
        }
        printf("%02x ", *(buffer + i));
    }
    printf("\n--------------------------------------------------\n");
    return;
}
#else
void DumpBuff(char *buffer, size_t bufLen)
{
    (void)buffer;
    (void)bufLen;
    return;
}
#endif

int bufLen = RSA_KEY_SIZE;
char msgBuf[THREAD_COUNT][RSA_KEY_SIZE] = {0};
char *shared_buf1[THREAD_COUNT] = {0};
char *shared_buf2[THREAD_COUNT] = {0};
pthread_t g_threads[THREAD_COUNT];
cc_enclave_t context = {0};

void *thread_func(void *args)
{
    int icount = ICOUNT;
    int count = 0;
    int retval = 0;
    int i = (int)(uint64_t)args;
    int cost = 0;
    struct timeval start, end;
    cc_enclave_result_t res = CC_FAIL;

    shared_buf1[i] = (char *)cc_malloc_shared_memory(&context, bufLen);
    if (shared_buf1[i] == NULL) {
        printf("Malloc shared memory failed.\n");
        goto error;
    }

    shared_buf2[i] = (char *)cc_malloc_shared_memory(&context, bufLen);
    if (shared_buf2[i] == NULL) {
        printf("Malloc shared memory failed.\n");
        res = cc_free_shared_memory(&context, shared_buf1[i]);
        if (res != CC_SUCCESS) {
            printf("Free shared memory failed:%x.\n", res);
        }
        goto error;
    }

    /* Generate Random data */
    if (GenerateRandomCmd(&context, &retval, msgBuf[i], RSA_MASSAGE_SIZE) != CC_SUCCESS) {
        goto error;
    }
    printf("random msg is : \n");
    DumpBuff(msgBuf[i], RSA_MASSAGE_SIZE);

    gettimeofday(&start, NULL);
    while(icount--){
        /*
	if (count%50 == 0) {
            gettimeofday(&end, NULL);
            cost = (end.tv_sec - start.tv_sec);
            printf("loop:%d, cost = %d s\n", count, cost);
        }
	*/
        count++;
        memcpy(shared_buf1[i], msgBuf[i], RSA_MASSAGE_SIZE);

        /* switchless ecall */
        res = RsaEncryptCmd(&context, &retval, shared_buf1[i], RSA_MASSAGE_SIZE, shared_buf2[i], bufLen);
        if (res != CC_SUCCESS || retval != (int)CC_SUCCESS) {
            printf("RsaEncryptCmd Switchless ecall error, count = %d, res = 0x%u, retval = %d\n", count, res, retval);
            printf("shared_buf1[%d] = %p\n", i, shared_buf1[i]);
            printf("shared_buf2[%d] = %p\n", i, shared_buf2[i]);
        }
        //printf("encBuf is : \n");
        DumpBuff(shared_buf2[i], bufLen);
        memset(shared_buf1[i], 0 , bufLen);

        res = RsaDecryptCmd(&context, &retval, shared_buf2[i], bufLen, shared_buf1[i], bufLen);
        if (res != CC_SUCCESS || retval != (int)CC_SUCCESS) {
            printf("RsaDecryptCmd Switchless ecall error, count = %d, res = 0x%u, retval = %d\n", count, res, retval);
            printf("shared_buf1[%d] = %p\n", i, shared_buf1[i]);
            printf("shared_buf2[%d] = %p\n", i, shared_buf2[i]);
        }
        //printf("decBuf is : \n");
        DumpBuff(shared_buf1[i], RSA_MASSAGE_SIZE);
        if (memcmp(shared_buf1[i], msgBuf[i], RSA_MASSAGE_SIZE) != 0) {
            printf("encrpt decrpt failed, count = %d\n", count);
            goto free;
        }
    }
    gettimeofday(&end, NULL);
    cost = (end.tv_sec - start.tv_sec) * 1000000 + (end.tv_usec - start.tv_usec);
    printf("total cost = %d us\n", cost);
    printf("Average time cost = %lf us, %d times\n", cost*1.0/ICOUNT, ICOUNT);
free:
    res = cc_free_shared_memory(&context, shared_buf1[i]);
    if (res != CC_SUCCESS) {
        printf("Free shared memory failed:%x.\n", res);
    }
    res = cc_free_shared_memory(&context, shared_buf2[i]);
    if (res != CC_SUCCESS) {
        printf("Free shared memory failed:%x.\n", res);
    }

error:
    return NULL;
}

int main()
{
    int  retval = 0;
    char *path = PATH;
    cc_enclave_result_t res = CC_FAIL;

    printf("Create secgear enclave\n");

    char real_p[PATH_MAX];
    /* check file exists, if not exist then use absolute path */
    if (realpath(path, real_p) == NULL) {
        if (getcwd(real_p, sizeof(real_p)) == NULL) {
            printf("Cannot find enclave.sign.so");
            goto end;
        }
        if (PATH_MAX - strlen(real_p) <= strlen("/enclave.signed.so")) {
            printf("Failed to strcat enclave.sign.so path");
            goto end;
        }
        (void)strcat(real_p, "/enclave.signed.so");
    }

    /* switchless configuration */
    cc_sl_config_t sl_cfg = CC_USWITCHLESS_CONFIG_INITIALIZER;
    sl_cfg.num_tworkers = 8; /* 2 tworkers */
    sl_cfg.sl_call_pool_size_qwords = 2; /* 2 * 64 tasks */
    enclave_features_t features = {ENCLAVE_FEATURE_SWITCHLESS, (void *)&sl_cfg};

    res = cc_enclave_create(real_p, AUTO_ENCLAVE_TYPE, 0, SECGEAR_DEBUG_FLAG, &features, 1, &context);
    if (res != CC_SUCCESS) {
        printf("Create enclave error\n");
        goto end;
    }

    /* Generate RSA keypair */
    if (RsaGenerateKeypairCmd(&context, &retval, RSA_KEY_SIZE, RSA_KEY_1) != CC_SUCCESS) {
        goto error;
    }

    for (int i = 0; i < THREAD_COUNT; i++) {
        pthread_create(&g_threads[i], NULL, thread_func, (void *)(uint64_t)i);
    }

    for (int i = 0; i < THREAD_COUNT; i++) {
        pthread_join(g_threads[i], NULL);
    }
error:
    res = cc_enclave_destroy(&context);
    if(res != CC_SUCCESS) {
        printf("Destroy enclave error\n");
    }
end:
    return res;
}


