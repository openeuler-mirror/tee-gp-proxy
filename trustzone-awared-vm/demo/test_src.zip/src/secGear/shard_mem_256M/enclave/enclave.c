/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2020. All rights reserved.
 * secGear is licensed under the Mulan PSL v2.
 * You can use this software according to the terms and conditions of the Mulan PSL v2.
 * You may obtain a copy of Mulan PSL v2 at:
 *     http://license.coscl.org.cn/MulanPSL2
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY OR FIT FOR A PARTICULAR
 * PURPOSE.
 * See the Mulan PSL v2 for more details.
 */

#include <stdio.h>
#include <string.h>
#include "switchless_t.h"

#define TA_HELLO_WORLD        "secgear hello world!"
#define TA_MID_HELLO		"this is mid!"
#define TA_END_HELLO		"this is end!"
#define PAGE_SIZE 1024*64
#define PAGE_NUM 4090
#define BUF_LEN PAGE_SIZE*PAGE_NUM
int get_string(char *buf)
{
    strncpy(buf, TA_HELLO_WORLD, strlen(TA_HELLO_WORLD) + 1);
    strncpy(buf        + PAGE_SIZE*(PAGE_NUM-1), TA_END_HELLO, strlen(TA_END_HELLO) + 1);
    return 0;
}

int get_string_switchless(char *shared_buf)
{
    strncpy(shared_buf, TA_HELLO_WORLD, strlen(TA_HELLO_WORLD) + 1);
    strncpy(shared_buf + PAGE_SIZE*(PAGE_NUM/2-1), TA_MID_HELLO, strlen(TA_END_HELLO) + 1);
    strncpy(shared_buf + PAGE_SIZE*(PAGE_NUM-1), TA_END_HELLO, strlen(TA_END_HELLO) + 1);
    return 0;
}

