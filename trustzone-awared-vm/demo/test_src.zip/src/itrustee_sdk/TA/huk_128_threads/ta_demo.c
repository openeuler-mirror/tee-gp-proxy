/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2020-2023. All rights reserved.
 * Licensed under the Mulan PSL v2.
 * You can use this software according to the terms and conditions of the Mulan PSL v2.
 * You may obtain a copy of Mulan PSL v2 at:
 *     http://license.coscl.org.cn/MulanPSL2
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY OR FIT FOR A PARTICULAR
 * PURPOSE.
 * See the Mulan PSL v2 for more details.
 * Description: TA template code for reference
 */

#include <tee_log.h>
#include <tee_crypto_api.h>
#include <fcntl.h>
#include <errno.h>
#include <string.h>
#include <pthread.h>
#include <stdint.h>
#include <stddef.h>
#include <pthread_attr.h>
#include <tee_ext_api.h>
#include <securec.h>

#define TA_TEMPLATE_VERSION "demo_20200601"
#define PARAM_COUNT      4
#define MARK_NUM 1
#define PRINT_LINE_LENGTH   32
#define EXE_NUM 100

int out_buff_index[] = {2, 3};
typedef struct {
    uint8_t *secret;
    uint32_t secret_len;
    uint8_t *key;
    uint32_t key_len;
} ThreadParam;

void DumpBuff(uint8_t *buffer, size_t bufLen)
{
    size_t i;
    if (buffer == NULL || bufLen == 0) {
        return;
    }
    tlogi("buflen = %d\n", bufLen);
    if (bufLen > 64) {
        bufLen = 64;
    }
    for (i = 0; i < bufLen; i++) {
        tloge("%02x ", *(buffer + i));
    }

    return;
}

TEE_Result CheckIsNotAllZero(uint8_t *buff, uint32_t len)
{
    uint32_t zeroCnt = 0;
    for (uint32_t i = 0; i < len ; i++) {
        if (buff[i] == 0)
            zeroCnt++;
        if (zeroCnt > len/3) {
            tloge("check huk_key failed, huk_len is null\n");
            DumpBuff(buff, len);
            return TEE_FAIL;
        }
    }
    return TEE_SUCCESS;
}

static void *Get_Key(void *param)
{
    TEE_Result result;
    ThreadParam *params = (ThreadParam *)param;
    uint8_t *secret = NULL;
    uint32_t secret_len = params->secret_len;
    uint8_t *key = NULL;
    uint32_t key_len = params->key_len;
    secret = TEE_Malloc(secret_len, 0);
    key = TEE_Malloc(key_len, 0);

    for (int i = 0; i < EXE_NUM; i++) {

        memset(key, 0, key_len);
        result = TEE_EXT_ROOT_DeriveKey2(secret, secret_len, key, key_len);
        if (result != TEE_SUCCESS) {
            tloge("%d loop, TEE_EXT_ROOT_DeriveKey2 failed, result = 0x%x", i + 1, result);
            TEE_Free(secret);
            TEE_Free(key);
            return (void *)(long)result;
        } else {
            result = CheckIsNotAllZero(key, key_len);
            if(result != TEE_SUCCESS) {
                TEE_Free(secret);
                TEE_Free(key);
                return (void *)(long)result;
            } else {
            }
        }
    }

    TEE_Free(secret);
    TEE_Free(key);
    return (void *)(long)result;
}

static int StartMultiThread(size_t threadNum, uint8_t *secret, uint32_t secret_len, uint8_t *key, uint32_t key_len)
{
    void *threadRet;
    int fail = 0;
    pthread_t *tid = NULL;
    ThreadParam *params = NULL;
    pthread_attr_t attr;

    if ((params = (ThreadParam *)malloc(sizeof(ThreadParam) * threadNum)) == NULL) {
        tloge("malloc failed\n");
        goto clean;
    }
    if ((tid = (pthread_t *)malloc(sizeof(pthread_t) * threadNum)) == NULL) {
        tloge("malloc failed\n");
        goto clean;        
    }

    pthread_attr_init(&attr);
    pthread_attr_settee(&attr, TEESMP_THREAD_ATTR_CA_INHERIT, TEESMP_THREAD_ATTR_TASK_ID_INHERIT,
        TEESMP_THREAD_ATTR_HAS_SHADOW);
    
    for (size_t i = 0; i < threadNum ; i++) {
        params[i].secret = secret;
        params[i].secret_len = secret_len;
        params[i].key = key;
        params[i].key_len = key_len;
        pthread_create(&tid[i], &attr, Get_Key, (void *)&params[i]);
    }
    for (size_t i = 0; i < threadNum ; i++) {
        pthread_join(tid[i], &threadRet);
        if ((uintptr_t)threadRet != TEE_SUCCESS) {
            tloge("child %d return err\n", i+1);
            fail++;
        } else {
            tlogi("success to get key, thread:%d\n", i + 1);
        }
    }

clean:
    free(tid);
    free(params);
    return fail;

}

/**
 * Function TA_CreateEntryPoint
 * Description:
 *   The function TA_CreateEntryPoint is the Trusted Application's constructor,
 *   which the Framework calls when it creates a new instance of this Trusted Application.
 */
TEE_Result TA_CreateEntryPoint(void)
{
    TEE_Result ret;

    tlogd("----- TA entry point ----- ");
    tlogd("TA version: %s", TA_TEMPLATE_VERSION);

    ret = addcaller_ca_exec("/vendor/bin/demo_hello", "root");
    if (ret == TEE_SUCCESS) {
        tlogd("TA entry point: add ca whitelist success");
    } else {
        tloge("TA entry point: add ca whitelist failed");
        return TEE_ERROR_GENERIC;
    }

    return TEE_SUCCESS;
}

/**
 * Function TA_OpenSessionEntryPoint
 * Description:
 *   The Framework calls the function TA_OpenSessionEntryPoint
 *   when a client requests to open a session with the Trusted Application.
 *   The open session request may result in a new Trusted Application instance
 *   being created.
 */
TEE_Result TA_OpenSessionEntryPoint(uint32_t parm_type,
    TEE_Param params[PARAM_COUNT], void** session_context)
{
    (void)parm_type;
    (void)params;
    (void)session_context;
    tlogd("---- TA open session -------- ");

    return TEE_SUCCESS;
}


/**
 * Function TA_InvokeCommandEntryPoint:
 * Description:
 *   The Framework calls this function when the client invokes a command
 *   within the given session.
 */
TEE_Result TA_InvokeCommandEntryPoint(void* session_context, uint32_t cmd,
    uint32_t parm_type, TEE_Param params[PARAM_COUNT])
{
    TEE_Result ret = TEE_SUCCESS;
    (void)session_context;

    tlogd("---- TA invoke command ----------- ");
    switch (cmd) {
    case MARK_NUM:
        if (!check_param_type(parm_type,
            TEE_PARAM_TYPE_NONE,
            TEE_PARAM_TYPE_NONE,
            TEE_PARAM_TYPE_MEMREF_OUTPUT,
            TEE_PARAM_TYPE_MEMREF_OUTPUT)) {
            tloge("Bad expected parameter types");
            return TEE_ERROR_BAD_PARAMETERS;
        }
        if (params[2].memref.buffer == NULL ||
            params[2].memref.size == 0 ||
            params[3].memref.buffer == NULL ||
            params[3].memref.size == 0) {
            tloge("InvokeCommand with bad, cmd is %u", cmd);
            return TEE_ERROR_BAD_PARAMETERS;
        }

        int res;
        uint32_t thread_nums[] = {8};
        for(int i = 0; i < 1; i++) {
            tlogi("start to execute thread %d\n", thread_nums[i]);
            res = StartMultiThread(thread_nums[i], params[2].memref.buffer, 
                params[2].memref.size, params[3].memref.buffer, params[3].memref.size);
            if (res) {
                ret = TEE_FAIL;
                tloge("Fail to execute thread %d, failed thread number:%d\n", thread_nums[i], res);
            } else {
                tlogi("success execute thread %d\n", thread_nums[i]);
            }
        }

        break;
    default:
        tloge("Unknown cmd is %u", cmd);
        ret = TEE_ERROR_BAD_PARAMETERS;
    }

    return  ret;
}

/**
 * Function TA_CloseSessionEntryPoint:
 * Description:
 *   The Framework calls this function to close a client session.
 *   During the call to this function the implementation can use
 *   any session functions.
 */
void TA_CloseSessionEntryPoint(void* session_context)
{
    (void)session_context;
    tlogd("---- close session ----- ");
}

/**
 * Function TA_DestroyEntryPoint
 * Description:
 *   The function TA_DestroyEntryPoint is the Trusted Application's destructor,
 *   which the Framework calls when the instance is being destroyed.
 */
void TA_DestroyEntryPoint(void)
{
    tlogd("---- destroy TA ---- ");
}

