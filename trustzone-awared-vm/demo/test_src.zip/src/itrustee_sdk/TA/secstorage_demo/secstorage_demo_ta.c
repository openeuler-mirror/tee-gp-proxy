/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2022-2022. All rights reserved.
 * Description: secstorage demo trusted application
 */

#include "string.h"
#include "tee_ext_api.h"
#include "tee_log.h"
#include "tee_defines.h"
#include "tee_mem_mgmt_api.h"
#include "tee_object_api.h"
#include "tee_trusted_storage_api.h"

#define UNSIGN_INT_MASK     0xffffffff

enum {
    CMD_SECSTORAGE_CREATE_FILE = 0x1,
    CMD_SECSTORAGE_READ_FILE,
    CMD_SECSTORAGE_DELETE_FILE,
    CMD_SECSTORAGE_WRITE_FILE,
    CMD_SECSTORAGE_RENAME_FILE,
    CMD_SECSTORAGE_TRUNCATE_FILE,
    CMD_SECSTORAGE_SEEK_FILE,
    CMD_SECSTORAGE_TRANSIENT_AES_KEY = 0x10,
};

static TEE_Result TA_SecstorageCreateFile(uint32_t paramTypes, TEE_Param params[4])
{
    char *path = NULL;
    char *writeBuff = NULL;
    uint32_t pathLen, flags, writeLen;
    TEE_ObjectHandle object = NULL;
    TEE_Result ret;

    SLogTrace("TA secstorage create file is running.");

    path = params[0].memref.buffer;
    pathLen = params[0].memref.size;
    writeBuff = params[2].memref.buffer;
    writeLen = params[2].memref.size;
    flags = params[1].value.a & (~TEE_DATA_FLAG_AES256);

    /* call TEE Storage API to open file */
    if (flags & TEE_DATA_FLAG_EXCLUSIVE) {
        ret = TEE_CreatePersistentObject(TEE_OBJECT_STORAGE_PRIVATE, path, pathLen,
            flags, TEE_HANDLE_NULL, writeBuff, writeLen, &object);
    } else if (flags & TEE_DATA_FLAG_CREATE) {
        ret = TEE_CreatePersistentObject(TEE_OBJECT_STORAGE_PRIVATE, path, pathLen,
            flags & (~TEE_DATA_FLAG_CREATE), TEE_HANDLE_NULL, writeBuff, writeLen, &object);
    } else {
        ret = TEE_OpenPersistentObject(TEE_OBJECT_STORAGE_PRIVATE, path, pathLen, flags, &object);
    }

    if (ret) {
        SLogError("create or open failed.");
        return ret;
    }

    params[3].value.a = (uint64_t)object->dataPtr & UNSIGN_INT_MASK;
    SLogTrace("TA secstorage create file, fd is 0x%x.", object->dataPtr);

    TEE_CloseObject(object);
    return TEE_SUCCESS;
}

static TEE_Result TA_SecstorageReadFile(uint32_t paramTypes, TEE_Param params[4])
{
    char *path = NULL;
    char *readBuff = NULL;
    uint32_t pathLen, flags, readLen, realReadLen;
    TEE_ObjectHandle object = NULL;
    TEE_Result ret;

    SLogTrace("TA secstorage read file is running.\n");

    path = params[0].memref.buffer;
    pathLen = params[0].memref.size;
    readBuff = params[2].memref.buffer;
    readLen = params[2].memref.size;
    flags = params[1].value.a;
    flags = flags & (~TEE_DATA_FLAG_AES256);
    
    ret = TEE_OpenPersistentObject(TEE_OBJECT_STORAGE_PRIVATE, path, pathLen, flags, &object);
    if (ret) {
        SLogError("open failed.");
        return ret;
    }

    ret = TEE_ReadObjectData(object, (void *)readBuff, readLen, &realReadLen);
    if (ret) {
        SLogError("read failed.");
        goto clean;
    }

    params[2].memref.size = realReadLen;
    params[3].value.a = (uint64_t)object->dataPtr & UNSIGN_INT_MASK;
    SLogTrace("TA secstorage read file success, fd is: 0x%x.", object->dataPtr);

clean:
    TEE_CloseObject(object);
    return ret;
}

static TEE_Result TA_SecstorageDeleteFile(uint32_t paramTypes, TEE_Param params[4])
{
    char *path = NULL;
    uint32_t pathLen, flags;
    TEE_ObjectHandle object = NULL;
    TEE_Result ret;

    SLogTrace("TA secstorage delete file is running.\n");

    path = params[0].memref.buffer;
    pathLen = params[0].memref.size;
    flags = params[1].value.a;
    flags = (flags & (~TEE_DATA_FLAG_AES256));

    ret = TEE_OpenPersistentObject(TEE_OBJECT_STORAGE_PRIVATE, path, pathLen, flags, &object);
    if (ret) {
        SLogError("open failed");
        return ret;
    }

    TEE_CloseAndDeletePersistentObject(object);
    SLogTrace("TA secstorage close and delete object success.");
    return ret;
}

static TEE_Result TA_SecstorageWriteFile(uint32_t paramTypes, TEE_Param params[4])
{
    char *path = NULL;
    uint32_t pathLen, flags, writeLen;
    char *writeBuff = NULL;
    TEE_ObjectHandle object = NULL;
    TEE_Result ret;
    TEE_ObjectInfo objectinfo;

    path = params[0].memref.buffer;
    pathLen = params[0].memref.size;
    writeBuff = params[2].memref.buffer;
    writeLen = params[2].memref.size;
    flags = params[1].value.a;
    flags = (flags & (~TEE_DATA_FLAG_AES256));

    if (flags & TEE_DATA_FLAG_EXCLUSIVE) {
        ret = TEE_CreatePersistentObject(TEE_OBJECT_STORAGE_PRIVATE, path, pathLen,
            flags, TEE_HANDLE_NULL, NULL, 0, &object);
    } else if (flags & TEE_DATA_FLAG_CREATE) {
        ret = TEE_CreatePersistentObject(TEE_OBJECT_STORAGE_PRIVATE, path, pathLen,
            flags & (~TEE_DATA_FLAG_CREATE), TEE_HANDLE_NULL, NULL, 0, &object);
    } else {
        ret = TEE_OpenPersistentObject(TEE_OBJECT_STORAGE_PRIVATE, path, pathLen, flags, &object);
    }

    if (ret) {
        SLogError("create or open failed");
        return ret;
    }

    ret = TEE_WriteObjectData(object, (void *)writeBuff, writeLen);
    if (ret) {
        SLogError("write failed.");
        goto clean;
    }

    params[3].value.a = (uint64_t)object->dataPtr & UNSIGN_INT_MASK;
    SLogTrace("TA secstorage write file, fd is:0x%x.", object->dataPtr);

    TEE_GetObjectInfo(object, &objectinfo);
    if ((objectinfo.dataSize != writeLen) || (objectinfo.dataPosition != writeLen)) {
        SLogError("after write, info file: len=%d, pos=%d\n", objectinfo.dataSize, objectinfo.dataPosition);
        goto clean;
    }
    SLogTrace("TA secstorage check object ok.");

clean:
    TEE_CloseObject(object);
    return ret;
}

static TEE_Result TA_SecstorageRenameFile(uint32_t paramTypes, TEE_Param params[4])
{
    char *path = NULL;
    uint32_t pathLen, flags, newObjectIDLen;
    char *newObjectID = NULL;
    TEE_ObjectHandle object = NULL;
    TEE_Result ret;

    path = params[0].memref.buffer;
    pathLen = params[0].memref.size;
    newObjectID = params[2].memref.buffer;
    newObjectIDLen = params[2].memref.size;
    flags = params[1].value.a;
    flags = (flags & (~TEE_DATA_FLAG_AES256));

    if (flags & TEE_DATA_FLAG_EXCLUSIVE) {
        ret = TEE_CreatePersistentObject(TEE_OBJECT_STORAGE_PRIVATE, path, pathLen,
            flags, TEE_HANDLE_NULL, NULL, 0, &object);
    } else if (flags & TEE_DATA_FLAG_CREATE) {
        ret = TEE_CreatePersistentObject(TEE_OBJECT_STORAGE_PRIVATE, path, pathLen,
            flags & (~TEE_DATA_FLAG_CREATE), TEE_HANDLE_NULL, NULL, 0, &object);
    } else {
        ret = TEE_OpenPersistentObject(TEE_OBJECT_STORAGE_PRIVATE, path, pathLen, flags, &object);
    }

    if (ret) {
        SLogError("create or open failed.");
        return ret;
    }

    ret = TEE_RenamePersistentObject(object, (void *)newObjectID, newObjectIDLen);
    if (ret) {
        SLogError("rename failed. return 0x%x.", ret);
        goto clean;
    }

    params[3].value.a = (uint64_t)object->dataPtr & UNSIGN_INT_MASK;
    SLogTrace("TA secstorage rename file success, fd is: 0x%x.", object->dataPtr);

clean:
    TEE_CloseObject(object);
    return ret;
}

static TEE_Result TA_SecstorageTruncateFile(uint32_t paramTypes, TEE_Param params[4])
{
    char *path = NULL;
    uint32_t pathLen, flags, truncateSize;
    TEE_ObjectHandle object = NULL;
    TEE_Result ret;

    SLogTrace("TA secstorage truncate file is running.");

    path = params[0].memref.buffer;
    pathLen = params[0].memref.size;
    truncateSize = params[2].value.a;
    flags = params[1].value.a;
    flags = (flags & (~TEE_DATA_FLAG_AES256));

    if (flags & TEE_DATA_FLAG_EXCLUSIVE) {
        ret = TEE_CreatePersistentObject(TEE_OBJECT_STORAGE_PRIVATE, path, pathLen,
            flags, TEE_HANDLE_NULL, NULL, 0, &object);
    } else if (flags & TEE_DATA_FLAG_CREATE) {
        ret = TEE_CreatePersistentObject(TEE_OBJECT_STORAGE_PRIVATE, path, pathLen,
            flags & (~TEE_DATA_FLAG_CREATE), TEE_HANDLE_NULL, NULL, 0, &object);
    } else {
        ret = TEE_OpenPersistentObject(TEE_OBJECT_STORAGE_PRIVATE, path, pathLen, flags, &object);
    }

    if (ret) {
        SLogError("create or open failed");
        return ret;
    }

    ret = TEE_TruncateObjectData(object, truncateSize);
    if (ret) {
        SLogError("truncate failed. return 0x%x.", ret);
        goto clean;
    }

    if (object->ObjectInfo->dataSize != truncateSize) {
        SLogError("failed to execute truncate object data: objectinfo->datasize = %d.", object->ObjectInfo->dataSize);
        goto clean;
    }

    SLogTrace("TA secstorage file truncate success.");
    params[3].value.a = (uint64_t)object->dataPtr & UNSIGN_INT_MASK;
    SLogTrace("TA secstorage file truncate, fd is: 0x%x.", object->dataPtr);

clean:
    TEE_CloseObject(object);
    SLogTrace("TA secstorage close object.\n");
    return ret;
}

static TEE_Result TA_SecstorageSeekFile(uint32_t paramTypes, TEE_Param params[4])
{
    char *path = NULL;
    uint32_t pathLen, flags;
    int32_t offset;
    TEE_Whence whence;
    TEE_ObjectHandle object = NULL;
    TEE_Result ret;

    path = params[0].memref.buffer;
    pathLen = params[0].memref.size;
    flags = params[1].value.a;
    flags = (flags & (~TEE_DATA_FLAG_AES256));
    offset = (int32_t)(params[2].value.a);
    whence = (TEE_Whence)(params[3].value.a);

    ret = TEE_OpenPersistentObject(TEE_OBJECT_STORAGE_PRIVATE, path, pathLen, flags, &object);
    if (ret) {
        SLogError("create of open failed.");
        return ret;
    }

    ret = TEE_SeekObjectData(object, offset, whence);
    if (ret) {
        SLogError("seek failed. return 0x%x.", ret);
        goto clean;
    }

    SLogTrace("Executre Seek Object Data: ObjectInfo->dataSize = %d", object->ObjectInfo->dataSize);
    SLogTrace("TA secstorage file seek, fd is: 0x%x.", object->dataPtr);

clean:
    TEE_CloseObject(object);
    SLogTrace("TA secstorage close object.\n");
    return ret;
}

static TEE_Result SaveAttributeTest(TEE_ObjectHandle keyObject, TEE_Attribute *attribute)
{
    char *attrBuffer = "test save attribute\n";
    TEE_Result ret;

    TEE_InitRefAttribute(attribute, TEE_ATTR_SECRET_VALUE, attrBuffer, strlen(attrBuffer));
    ret = TEE_PopulateTransientObject(keyObject, attribute, 1);
    if (ret) {
        SLogError("failed to execute TEE_PopulateTransientObject: ret=%d\n", ret);
        return ret;
    }

    char getBuff[128] = {0};
    size_t getSize = 128;
    ret = TEE_GetObjectBufferAttribute(keyObject, TEE_ATTR_SECRET_VALUE, getBuff, &getSize);
    if (ret) {
        SLogError("failed to execute TEE_GetObjectBufferAttribute: ret = %d\n", ret);
    }

    return ret;
}

static TEE_Result CopyObjectTest(TEE_ObjectHandle keyObject, uint32_t keySize, TEE_Attribute *attribute)
{
    TEE_ObjectHandle keyObjectReplica = NULL;

    if (TEE_AllocateTransientObject(TEE_TYPE_AES, keySize, &keyObjectReplica)) {
        SLogError("allocate transient object replica failed.");
        return TEE_FAIL;
    }

    TEE_CopyObjectAttributes(keyObjectReplica, keyObject);

    SLogTrace("execute transient aes key object replica data: objectinfo->datasize = %d.",
        keyObjectReplica->ObjectInfo->dataSize);
    SLogTrace("execute transient aes key object replica data: objectinfo->Attribute = %d. ", keyObjectReplica->Attribute);
    SLogTrace("execute transient aes key object replica data: Attribute->length = %d", 
        keyObjectReplica->Attribute->content.ref.length);
    SLogTrace("execute transient aes key object data: object->attribute = %d.", keyObject->Attribute);
    SLogTrace("execute transient aes key object data: attribute->length = %d.",
        keyObject->Attribute->content.ref.length);
    SLogTrace("execute transient aes key object data: attribute = %d", attribute);
    SLogTrace("TA secstorage transient AES key, fd is: 0x%x.", keyObjectReplica->dataPtr);

    TEE_ResetTransientObject(keyObjectReplica);
    TEE_FreeTransientObject(keyObjectReplica);

    return TEE_SUCCESS;
}

static TEE_Result TA_SecstorageTransientAESkey(uint32_t paramTypes, TEE_Param params[4])
{
    TEE_ObjectHandle keyObject = NULL;
    TEE_Attribute *attribute = NULL;
    uint32_t keySize;
    TEE_Result ret;

    SLogTrace("TA secstorage transient AES key is running.");

    keySize = params[0].value.a;
    SLogTrace("keySize = 0x%x\n.", keySize);

    ret = TEE_AllocateTransientObject(TEE_TYPE_AES, keySize, &keyObject);
    if (ret) {
        SLogError("Allocate transient object failed.");
        return ret;
    }

    attribute = (TEE_Attribute *)TEE_Malloc(sizeof(TEE_Attribute), 0);
    if (attribute == NULL) {
        SLogError("not available to allocate.");
        return ret;
    }

    if (SaveAttributeTest(keyObject, attribute)) {
        goto clean;
    }

    uint32_t objectUsage = (TEE_USAGE_ENCRYPT | TEE_USAGE_DECRYPT);
    TEE_RestrictObjectUsage(keyObject, objectUsage);

    ret = TEE_GenerateKey(keyObject, keySize, NULL, 0);
    if (ret) {
        SLogError("generate key failed.");
        goto clean;
    }

    if (CopyObjectTest(keyObject, keySize, attribute)) {
        goto clean;
    }
    TEE_ResetTransientObject(keyObject);

clean:
    if (attribute != NULL) {
        TEE_Free(attribute);
    }
    TEE_FreeTransientObject(keyObject);
    return ret;
}

TEE_Result TA_CreateEntryPoint(void)
{
    const char *caPath = "/vendor/bin/secstorage_demo";

    if (addcaller_ca_exec(caPath, "root")) {
        SLogError("add caller for ca exec failed.");
        return TEE_ERROR_GENERIC;
    }

    SLogTrace("TA_CreateEntryPoint: AddCaller_CA_exec ok.");

    return TEE_SUCCESS;
}

TEE_Result TA_OpenSessionEntryPoint(uint32_t paramTypes, TEE_Param params[4], void **sessionContext)
{
    SLogTrace("SecStorage open session entry point ok.");

    return TEE_SUCCESS;
}

TEE_Result TA_InvokeCommandEntryPoint(void *context, uint32_t cmdId, uint32_t paramTypes, TEE_Param params[4])
{
    TEE_Result ret;

    SLogTrace("Secstorage demo ta invoke command entry point");

    switch (cmdId)
    {
        case CMD_SECSTORAGE_CREATE_FILE:
            ret = TA_SecstorageCreateFile(paramTypes, params);
            break;
        
        case CMD_SECSTORAGE_READ_FILE:
            ret = TA_SecstorageReadFile(paramTypes, params);
            break;

        case CMD_SECSTORAGE_DELETE_FILE:
            ret = TA_SecstorageDeleteFile(paramTypes, params);
            break;

        case CMD_SECSTORAGE_WRITE_FILE:
            ret = TA_SecstorageWriteFile(paramTypes, params);
            break;

        case CMD_SECSTORAGE_RENAME_FILE:
            ret = TA_SecstorageRenameFile(paramTypes, params);
            break;

        case CMD_SECSTORAGE_TRUNCATE_FILE:
            ret = TA_SecstorageTruncateFile(paramTypes, params);
            break;

        case CMD_SECSTORAGE_SEEK_FILE:
            ret = TA_SecstorageSeekFile(paramTypes, params);
            break;

        case CMD_SECSTORAGE_TRANSIENT_AES_KEY:
            ret = TA_SecstorageTransientAESkey(paramTypes, params);
            break;

        default:
            SLogError("Unknow CMD ID: %d", cmdId);
            ret = TEE_FAIL;
            break;
    }

    if (ret) {
        SLogError("Secstorage demo ta invoke command entry point failed 0x%x. cmd_id is %d.", ret, cmdId); 
    }

    return ret;
}