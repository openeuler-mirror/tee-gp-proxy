You need to install the pycryptodome library of python and run the make command to compile the binary of ta.

If TA wants to regist driver's permission, you must have dynamic permission file and driver's excel
The name of the dynamic permission file must be 'dyn_perm.xml', the driver's excel's name can be 'driver name'.xlsx, and you can get it from driver's developer.
You must install the xlrd-1.2.0 and defusedxml-0.7.1 library of python and run the make command to sign the binary of ta.