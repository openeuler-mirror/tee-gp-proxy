/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2020-2023. All rights reserved.
 * Licensed under the Mulan PSL v2.
 * You can use this software according to the terms and conditions of the Mulan PSL v2.
 * You may obtain a copy of Mulan PSL v2 at:
 *     http://license.coscl.org.cn/MulanPSL2
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY OR FIT FOR A PARTICULAR
 * PURPOSE.
 * See the Mulan PSL v2 for more details.
 * Description: TA template code for reference
 */
#include <sched.h>
#include <stddef.h>
#include <stdint.h>
#include <tee_ext_api.h>
#include <tee_log.h>
#include <tee_crypto_api.h>
#include <tee_crypto_hal.h>
#include <tee_object_api.h>
#include <tee_time_api.h>
#include <pthread.h>
#include <pthread_attr.h>

#include <securec.h>

#define TA_TEMPLATE_VERSION "demo_20200601"
#define PARAM_COUNT      4

#define PARAMS_IDX4 4

#define RANDOM_CMD 1
#define RSA_CMD 2
#define KEY_CMD 3

TEE_ObjectHandle g_rsaKeyObj1;

typedef struct {
    char *buffer;
    size_t size;
} Buffer;

typedef struct {
    TEE_Param paramInfo[PARAMS_IDX4];
} ThreadParam;

void DumpBuff(char *buffer, size_t bufLen)
{
    size_t i;
    if (buffer == NULL || bufLen == 0) {
        return;
    }
    tlogi("buflen = %d\n", bufLen);
    if (bufLen > 64) {
        bufLen = 64;
    }
    for (i = 0; i < bufLen; i++) {
        tloge("%02x ", *(buffer + i));
    }

    return;
}

TEE_Result CheckIsNotAllZero(char *buff, uint32_t len)
{
    if (len < 256) {
        tloge("buffer length is less than 256\n");
        return TEE_FAIL;
    }

    uint32_t zeroCnt = 0;
    for (uint32_t i = 0; i < len ; i++) {
        if (buff[i] == 0)
            zeroCnt++;
        if (zeroCnt > len/3) {
            tloge("check huk_key failed, huk_len is null\n");
            DumpBuff(buff, len);
            return TEE_FAIL;
        }
    }
    return TEE_SUCCESS;
}

TEE_Result CheckBuf(Buffer *buf1, Buffer *buf2, uint32_t is_print)
{
    size_t i;

    if (buf1->size != buf2->size) {
        tloge("buf1->size != buf2->size\n");
        return TEE_FAIL;
    }

    for (i = 0; i < buf1->size; i++) {
        if (*(buf1->buffer + i) != *(buf2->buffer + i)) {
            tloge("not equal\n");
            return TEE_FAIL;
        }
    }

    if (is_print == 'y') {
        SLogTrace("Check successfully, length of buf: %d\n", buf1->size);
    }
    return TEE_SUCCESS;
}

TEE_Result Get_random(char *buffer, size_t buf_len)
{
    tlogi("---Start get random msg---\n");
    TEE_GenerateRandom(buffer, buf_len);
    tlogi("---End get random msg---\n");
    return TEE_SUCCESS;
}

TEE_Result Generate_Key()
{
    TEE_Result ret = TEE_SUCCESS;

    if (g_rsaKeyObj1 == NULL) {
        tlogi("...........get key.........");
        ret = TEE_AllocateTransientObject(TEE_TYPE_RSA_KEYPAIR, 512, &g_rsaKeyObj1);
        if (ret != TEE_SUCCESS) {
            tloge("CmdRSAGenKeypair:TEE_AllocateTransientObject failed");
            return ret;
        }
        ret = TEE_GenerateKey(g_rsaKeyObj1, 512, NULL, 0);
        if (ret != TEE_SUCCESS) {
            tloge("TEE_GenerateKey failed");
            return ret;
        }
    }
    return ret;
}
/************************************************************************************************************
 * 函数名称：CmdRSACryptoParamCheck
 * 功能描述：检测加密原文数据地址和加密数据的缓存的地址以及缓存大小是否存在
 * 参数    ：Operation ：TEE操作引擎
 *           buf1：     原文数据存储地址
 *           buf1_len： 原文长度
 *           buf2：     密文数据存储地址
 *           buf2_len   密文数据长度
 *           cryptmode：加密模式
 *           algorithm：加密算法的索引(即使用那种算法加密)
 * 返回类型：TEE_SUCCESS表示 参数检查完毕，且无异常
 * **********************************************************************************************************/
TEE_Result CmdRSACryptoParamCheck(TEE_OperationHandle *Operation, Buffer *buf1, Buffer *buf2,
                                  uint32_t cryptmode, uint32_t algorithm)
{
    TEE_Result ret;
    if ((buf1->buffer == NULL) || (buf1->size == 0) || (buf2->buffer == NULL) || (buf2->size == 0)) {
        SLogError("CmdRSACrypto: buf is null, or bufLen is 0.");
        return TEE_ERROR_BAD_PARAMETERS;
    }
    /* GP 1.2 define maxKeySize with bit unit. */
    ret = TEE_AllocateOperation(Operation, algorithm, cryptmode, buf2->size);
    if (ret != TEE_SUCCESS) {
        SLogError("CmdRSACrypto TEE_AllocateOperation failed.");
        return ret;
    }
    return TEE_SUCCESS;
}

/*****************************************************************************************************
 * 函数名称： CmdRSACrypto
 * 功能描述:  用之前生成的秘钥去加密之前生成的数据
 * 参数      num_key：  键值
 *           alg：      加密算法的索引
 *           buf1：     原文数据存储地址
 *           buf1_len： 原文长度
 *           buf2：     密文数据存储地址
 *           buf2_len   密文数据长度
 *           cryptmode：加密模式
 * 返回值 ：TEE_SUCCESS表示加密成功
 ***************************************************************************************************/
TEE_Result CmdRSACrypto(uint32_t alg, Buffer *buf1, Buffer *buf2, uint32_t cryptmode)
{
    TEE_Result ret;
    TEE_OperationHandle Operation = NULL;
    size_t outlen;
    uint32_t algorithm;
    algorithm = alg;
    outlen = buf2->size;

    ret = CmdRSACryptoParamCheck(&Operation, buf1, buf2, cryptmode, algorithm);
    if (ret != TEE_SUCCESS) {
        return ret;
    }

    ret = TEE_SetOperationKey(Operation, g_rsaKeyObj1);
    if (ret!=TEE_SUCCESS){
        tloge("TEE_SetOperationKey failed\n");
        TEE_FreeOperation(Operation);
        return ret;
    }

    if (cryptmode == TEE_MODE_ENCRYPT) {
        ret = TEE_AsymmetricEncrypt(Operation, NULL, 0, buf1->buffer, buf1->size, buf2->buffer, &outlen);
        if (ret != TEE_SUCCESS) {
            SLogError("CmdRSACrypto TEE_AsymmetricEncrypt failed. ret %x", ret);
        }
    } else if (cryptmode == TEE_MODE_DECRYPT) {
        ret = TEE_AsymmetricDecrypt(Operation, NULL, 0, buf1->buffer, buf1->size, buf2->buffer, &outlen);
        if (ret != TEE_SUCCESS) {
            SLogError("CmdRSACrypto TEE_AsymmetricDecrypt failed. ret %x", ret);
        }
    } else {
        SLogError("CmdRSACrypto TEE_AsymmetricDecrypt unkown mode: %d.", cryptmode);
        ret = TEE_ERROR_BAD_PARAMETERS;
    }
    if (ret == TEE_SUCCESS) {
        buf2->size = outlen;
    } else {
        buf2->size = 0;
    }
    TEE_FreeOperation(Operation);
    return ret;
}

static void *rsa_en_decrypt(void *param)
{
    ThreadParam *params = (ThreadParam *)param;
    int exe_num = params->paramInfo[2].value.b;
    TEE_Result ret;
    Buffer msg;
    Buffer en_out;
    Buffer de_out;
    msg.buffer = params->paramInfo[1].memref.buffer;
    msg.size = params->paramInfo[1].memref.size;

    for (int i= 0; i < exe_num; i++) {
        en_out.size = 512;
        en_out.buffer = (char*)TEE_Malloc(en_out.size, 0);
        de_out.size = 512;
        de_out.buffer = (char*)TEE_Malloc(de_out.size, 0); 
        if ((en_out.buffer == NULL)||(de_out.buffer == NULL)) {
            tloge("malloc failed\n");
            ret = TEE_ERROR_OUT_OF_MEMORY;
            goto clean;
        }

        ret = CmdRSACrypto(TEE_ALG_RSAES_PKCS1_OAEP_MGF1_SHA512, &msg, &en_out, TEE_MODE_ENCRYPT);
        if (ret != TEE_SUCCESS) {
            tloge("Rsa encrpty failed\n");
            goto clean;
        } else {
            ret = CheckIsNotAllZero(en_out.buffer, en_out.size);
            if (ret != TEE_SUCCESS) {
                goto clean;
            }
        }

        ret = CmdRSACrypto(TEE_ALG_RSAES_PKCS1_OAEP_MGF1_SHA512, &en_out, &de_out, TEE_MODE_DECRYPT);
        if (ret != TEE_SUCCESS) {
            tloge("Rsa decrpty failed\n");
            goto clean;
        } else {
            ret = CheckBuf(&msg, &de_out, 'n');
            if (ret != TEE_SUCCESS) {
                goto clean;
            }
        }
        TEE_Free(en_out.buffer);
        TEE_Free(de_out.buffer);
    }
clean:
    TEE_Free(en_out.buffer);
    TEE_Free(de_out.buffer);
    return (void *)(long)ret;
}

static int StartMultiThread(TEE_Param params[PARAMS_IDX4])
{
    void *threadRet;
    int fail = 0;
    pthread_t *tid = NULL;
    ThreadParam *tParams = NULL;
    pthread_attr_t attr;
    size_t threadNum = params[2].value.a;
    size_t startTime = 0;
    size_t endTime = 0;
    TEE_Time cur = {0};
    TEE_Result ret = TEE_SUCCESS;

    if ((tParams = (ThreadParam *)TEE_Malloc(sizeof(ThreadParam) * threadNum, 0)) == NULL) {
        tloge("malloc failed\n");
        goto clean;
    }
    if ((tid = (pthread_t *)TEE_Malloc(sizeof(pthread_t) * threadNum, 0)) == NULL) {
        tloge("malloc failed\n");
        goto clean;        
    }

    pthread_attr_init(&attr);
    pthread_attr_settee(&attr, TEESMP_THREAD_ATTR_CA_INHERIT, TEESMP_THREAD_ATTR_TASK_ID_INHERIT,
        TEESMP_THREAD_ATTR_HAS_SHADOW);
    
    TEE_GetSystemTime(&cur);
    startTime = cur.seconds * 1000 + cur.millis;
    for (size_t i = 0; i < threadNum ; i++) {
        tParams[i].paramInfo[0] = params[0];
        tParams[i].paramInfo[1] = params[1];
        tParams[i].paramInfo[2] = params[2];
        tParams[i].paramInfo[3] = params[3];        
        pthread_create(&tid[i], &attr, rsa_en_decrypt, (void *)&tParams[i]);
    }
    for (size_t i = 0; i < threadNum ; i++) {
        pthread_join(tid[i], &threadRet);
        if ((uintptr_t)threadRet != TEE_SUCCESS) {
            tloge("child %d return err\n", i+1);
            fail++;
        } else {
            tlogi("success to encrypt decrypt, thread:%d\n", i + 1);
        }
    }
    TEE_GetSystemTime(&cur);
    endTime = cur.seconds * 1000 + cur.millis;
    params[3].value.a = endTime - startTime;
    tlogi("-------thread_num %d run time:%d", threadNum, params[3].value.a);

    if (fail > 0) {
        tloge("Fail to execute thread %d, failed thread number:%d", threadNum, fail);
    }


clean:
    free(tid);
    free(tParams);
    return ret;

}

TEE_Result CheckParams(uint32_t param_type, uint32_t cmd)
{
    TEE_Result ret = TEE_SUCCESS;
    switch (cmd)
    {
    case KEY_CMD:
        if (!check_param_type(param_type,
            TEE_PARAM_TYPE_NONE,
            TEE_PARAM_TYPE_NONE,
            TEE_PARAM_TYPE_NONE,
            TEE_PARAM_TYPE_NONE)) {
                tloge("Bad paramtypes");
                return TEE_ERROR_BAD_PARAMETERS;
            }
        break;
    case RSA_CMD:
        if(!check_param_type(param_type,
            TEE_PARAM_TYPE_VALUE_INPUT,
            TEE_PARAM_TYPE_MEMREF_INPUT,
            TEE_PARAM_TYPE_VALUE_INPUT,
            TEE_PARAM_TYPE_NONE)) {
                tloge("Bad paramtypes");
                return TEE_ERROR_BAD_PARAMETERS;
            }
        break;
    case RANDOM_CMD:
        if(!check_param_type(param_type,
            TEE_PARAM_TYPE_NONE,
            TEE_PARAM_TYPE_NONE,
            TEE_PARAM_TYPE_NONE,
            TEE_PARAM_TYPE_MEMREF_OUTPUT)) {
                tloge("Bad paramtypes");
                return TEE_ERROR_BAD_PARAMETERS;
            } 
        break;
    default:
        tloge("unknown cmd is %u", cmd);
        ret = TEE_ERROR_BAD_PARAMETERS;
        break;
    }
    return ret;
}

/**
 * Function TA_CreateEntryPoint
 * Description:
 *   The function TA_CreateEntryPoint is the Trusted Application's constructor,
 *   which the Framework calls when it creates a new instance of this Trusted Application.
 */
TEE_Result TA_CreateEntryPoint(void)
{
    TEE_Result ret;

    tlogd("----- TA entry point ----- ");
    tlogd("TA version: %s", TA_TEMPLATE_VERSION);

    ret = addcaller_ca_exec("/vendor/bin/rsa_4096", "root");
    if (ret == TEE_SUCCESS) {
        tlogd("TA entry point: add ca whitelist success");
    } else {
        tloge("TA entry point: add ca whitelist failed");
        return TEE_ERROR_GENERIC;
    }

    return TEE_SUCCESS;
}

/**
 * Function TA_OpenSessionEntryPoint
 * Description:
 *   The Framework calls the function TA_OpenSessionEntryPoint
 *   when a client requests to open a session with the Trusted Application.
 *   The open session request may result in a new Trusted Application instance
 *   being created.
 */
TEE_Result TA_OpenSessionEntryPoint(uint32_t parm_type,
    TEE_Param params[PARAM_COUNT], void** session_context)
{
    (void)parm_type;
    (void)params;
    (void)session_context;
    tlogd("---- TA open session -------- ");

    return TEE_SUCCESS;
}


/**
 * Function TA_InvokeCommandEntryPoint:
 * Description:
 *   The Framework calls this function when the client invokes a command
 *   within the given session.
 */
TEE_Result TA_InvokeCommandEntryPoint(void* session_context, uint32_t cmd,
    uint32_t parm_type, TEE_Param params[PARAM_COUNT])
{
    TEE_Result ret = TEE_SUCCESS;
    (void)session_context;

    ret = CheckParams(parm_type, cmd);
    if (ret != TEE_SUCCESS) {
        tloge("check params failed");
        return ret;
    }

    tlogi("---- TA invoke command ----------- ");
    switch (cmd) {
    case RANDOM_CMD:
        tlogi("Start ta random");
        ret = Get_random(params[3].memref.buffer, params[3].memref.size);
        break;
    case RSA_CMD:
        tlogi("Start ta test");
        ret = StartMultiThread(params);
        break;
    case KEY_CMD:
        ret = Generate_Key();
        break;
    default:
        tloge("Unknown cmd is %u", cmd);
        ret = TEE_ERROR_BAD_PARAMETERS;
    }

    if (ret != TEE_SUCCESS) {
        tloge("InvokeCommand Failed 0x%x, cmd is %u", ret, cmd);
    }

    return  ret;
}

/**
 * Function TA_CloseSessionEntryPoint:
 * Description:
 *   The Framework calls this function to close a client session.
 *   During the call to this function the implementation can use
 *   any session functions.
 */
void TA_CloseSessionEntryPoint(void* session_context)
{
    (void)session_context;
    tlogd("---- close session ----- ");
}

/**
 * Function TA_DestroyEntryPoint
 * Description:
 *   The function TA_DestroyEntryPoint is the Trusted Application's destructor,
 *   which the Framework calls when the instance is being destroyed.
 */
void TA_DestroyEntryPoint(void)
{
    tlogd("---- destroy TA ---- ");
}


