/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2020-2022. All rights reserved.
 * iTrustee licensed under the Mulan PSL v2.
 * You can use this software according to the terms and conditions of the Mulan PSL v2.
 * You may obtain a copy of Mulan PSL v2 at:
 *     http://license.coscl.org.cn/MulanPSL2
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY OR FIT FOR A PARTICULAR
 * PURPOSE.
 * See the Mulan PSL v2 for more details.
 * Description: rsa-demo
 */
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <errno.h>
#include <string.h>
#include <sys/time.h>
#include <sys/sysinfo.h>
#include <stddef.h>
#include <stdint.h>
#include <pthread.h>
#include "tee_client_api.h"
#include <sched.h>

static const TEEC_UUID DEMO_TEMPLATE_UUID =
{
    0xe8d37f4a, 0xf24c, 0x48d0,
    { 0x88, 0x84, 0x3b, 0xdd, 0x6c, 0x44, 0xe9, 0x88 }
};

#define TEEC_DEBUG
#define RSA_KEY_SIZE                256    // 2048bits
#define RSA_MASSAGE_SIZE            100    // see rsa-demoTA.c, massage size has some limitation.
#define RSA_KEY_1                   1
#define RSA_ALG_OAEP_SHA512         1      // use TEE_ALG_RSAES_PKCS1_OAEP_MGF1_SHA512 mode for crypto
#define RSA_ALG_PSS_SHA256          2      // use TEE_ALG_RSASSA_PKCS1_PSS_MGF1_SHA256 mode for sign
#define RSA_INPUT_ERROR_PARAMETER   0x10000001
#define PRINTF_SIZE                 32

#define CA_THREAD_NUM 4
#define TA_THREAD_NUM 8
#define EXE_NUM 30

#define RANDOM_CMD 1
#define RSA_CMD 2
#define KEY_CMD 3

typedef struct {
    char *buffer;
    int size;
} Buffer;

typedef struct {
    uint32_t threadID;
    Buffer msg;
} ThreadParam;

int res_code = 0;
TEEC_Context context;
TEEC_Session session;

long GetTimeUs(void)
{
    struct timeval cur;
    gettimeofday(&cur, NULL);
    return cur.tv_sec*1000*1000 + cur.tv_usec;
}

TEEC_Result rsa_en_decrypt(Buffer *in_msg, uint32_t threadId)
{
    uint32_t origin;
    TEEC_Result ret = TEEC_SUCCESS;
    TEEC_Operation operation;
    TEEC_Session gsession;

    operation.started = 1;
    ret = TEEC_OpenSession(&context, &gsession, &DEMO_TEMPLATE_UUID, TEEC_LOGIN_IDENTIFY, NULL, &operation, &origin);
    if (ret) {
        printf("teec open session failed, threadId = %u\n", threadId);
        res_code = -1;
        goto close;
    }
    printf("thrd TEEC_OpenSession success, threadId = %u\n", threadId);
    operation.paramTypes = TEEC_PARAM_TYPES(TEEC_VALUE_INPUT, TEEC_MEMREF_TEMP_INPUT, TEEC_VALUE_INPUT, TEEC_NONE);
    operation.params[0].value.a = RSA_KEY_1;
    operation.params[0].value.b = RSA_ALG_OAEP_SHA512;
    operation.params[1].tmpref.buffer = in_msg->buffer;
    operation.params[1].tmpref.size = in_msg->size;
    operation.params[2].value.a = TA_THREAD_NUM;
    operation.params[2].value.b = EXE_NUM;
    
    if ((ret = TEEC_InvokeCommand(&gsession, RSA_CMD, &operation, &origin))) {
        printf("Do cipher failed, codes = 0x%x, origin = 0x%x\n", ret, origin);
        goto close;
    }
    printf("thrd TEEC_InvokeCommand success, threadId = %u\n", threadId);
close:
    TEEC_CloseSession(&gsession);
    return ret;
}

void FreeBuffer(Buffer *buf)
{
    if (buf == NULL || buf->buffer == NULL)
        return;
    free(buf->buffer);
    buf->buffer = NULL;
    buf->size = 0;
}

TEEC_Result CheckIsNotAllZero(char *buffer, size_t buf_len)
{
    uint32_t zerocnt = 0;
    for (uint32_t i = 0; i < buf_len; i++) {
        if (buffer[i] == 0)
            zerocnt++;
        if (zerocnt > buf_len/3) {
            printf("check buffer failed, buffer is null\n");
            return TEEC_FAIL;
        }
    }
    return TEEC_SUCCESS;
}

TEEC_Result Get_Random(Buffer *mem)
{
    TEEC_Operation operation;
    uint32_t origin;
    TEEC_Result result;

    operation.started = 1;
    operation.paramTypes = TEEC_PARAM_TYPES(TEEC_NONE, TEEC_NONE, TEEC_NONE, TEEC_MEMREF_TEMP_OUTPUT);
    operation.params[3].tmpref.buffer = mem->buffer;
    operation.params[3].tmpref.size = mem->size;

    result = TEEC_InvokeCommand(&session, RANDOM_CMD, &operation, &origin);

    if (result) {
        printf("get random failed, coddx = 0x%x, origin = 0x%x\n", result, origin); 
    } else {
        result = CheckIsNotAllZero(mem->buffer, mem->size);
        if (result)
            goto close;
    }

close:
    return result;
}

TEEC_Result Get_Key(void)
{
    TEEC_Operation operation;
    uint32_t origin;
    TEEC_Result result; 
    operation.started = 1;
    operation.paramTypes = TEEC_PARAM_TYPES(TEEC_NONE, TEEC_NONE, TEEC_NONE, TEEC_NONE);

    result = TEEC_InvokeCommand(&session, KEY_CMD, &operation, &origin);
    if (result) {
        printf("get key failed, coddx = 0x%x, origin = 0x%x\n", result, origin); 
    }

close:
    return result;
}

TEEC_Result CpuBind(int threadId)
{
    pthread_t tid;
    int cpuid;
    cpu_set_t cpuset;

    tid = pthread_self();
    cpuid = (threadId - 1) % get_nprocs();
    CPU_ZERO(&cpuset);
    CPU_SET(cpuid, &cpuset);

    if (pthread_setaffinity_np(tid, sizeof(cpu_set_t), &cpuset) != 0) {
        printf("[child_%d] set thread affinity failed \n", threadId);
        return TEEC_FAIL;
    }
    return TEEC_SUCCESS;
}

static void *Test(void *param)
{
    TEEC_Result result;
    ThreadParam *params = (ThreadParam *)param;
    Buffer msg = params->msg;
    uint32_t threadId = params->threadID;
    CpuBind(threadId);

    result = rsa_en_decrypt(&msg, threadId);
    if (result)
        return (void*)result;
    return (void*)result;
}

static int StartMultiThread(Buffer in_msg, size_t threadNum)
{
    void *threadRet;
    int fail = 0;
    pthread_t *tid = NULL;
    ThreadParam *params = NULL;
    long start, end;

    if ((params = (ThreadParam *)malloc(sizeof(ThreadParam) * threadNum)) == NULL) {
        printf("malloc failed\n");
        goto clean;
    }
    if ((tid = (pthread_t *)malloc(sizeof(pthread_t) * threadNum)) == NULL) {
        printf("malloc failed\n");
        goto clean;
    }

    start = GetTimeUs();
    for (uint32_t i = 0; i < threadNum; i++) {
        params[i].threadID = i+1;
        params[i].msg = in_msg;
        pthread_create(&tid[i], NULL, Test, (void *)&params[i]);
    }

    for (uint32_t i = 0; i < threadNum; i++) {
        pthread_join(tid[i], &threadRet);
        if ((TEEC_Result)threadRet != TEEC_SUCCESS) {
            printf("child %d return error\n", i+1);
            fail++;
        }
    }
    end = GetTimeUs();
    printf("Success to run rsa_4096, thread:%d, run_time:%ld ms\n", threadNum, (end - start)/1000);

clean:
    free(tid);
    free(params);
    return fail;
}

int main(void)
{
    TEEC_Result result;
    TEEC_Operation operation;
    uint32_t origin;
    Buffer msg;

    result = TEEC_InitializeContext(NULL, &context);
    if (result) {
        printf("teec init failed\n");
        res_code = -1;
        goto close_1;
    }
    printf("TEEC_InitializeContext success\n");
    operation.started = 1;
    operation.paramTypes = TEEC_PARAM_TYPES(TEEC_NONE, TEEC_NONE, TEEC_NONE, TEEC_NONE);
    result = TEEC_OpenSession(&context, &session, &DEMO_TEMPLATE_UUID, TEEC_LOGIN_IDENTIFY, NULL, &operation, &origin);
    if (result) {
        printf("TEEC_OpenSession failed\n");
        res_code = -1;
        goto close_2;
    }
    printf("main TEEC_OpenSession success\n");
    result = Get_Key();
    if (result) {
        res_code = -1;
        goto close_1;
    }
    printf("get key success\n");
    msg.buffer = (char*)malloc(RSA_MASSAGE_SIZE);
    msg.size = RSA_MASSAGE_SIZE;
    result = Get_Random(&msg);
    if (result) {
        printf("get msg failed\n");
        res_code = -1;
        goto clean;
    }
    printf("get random msg success\n");

    int fail_cou;
    fail_cou = StartMultiThread(msg, CA_THREAD_NUM);
    if (fail_cou > 0) {
        res_code = -1;
        printf("Fail to execute thread %d, failed thread number:%d\n", CA_THREAD_NUM, fail_cou);
        goto clean;
    }

clean:
    FreeBuffer(&msg);
close_2:
    TEEC_CloseSession(&session);
close_1:
    TEEC_FinalizeContext(&context);
    return res_code;
}

