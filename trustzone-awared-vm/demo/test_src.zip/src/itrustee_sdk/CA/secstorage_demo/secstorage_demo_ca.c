/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2020-2020. All rights reserved.
 * Description: secstorage_demo ca source
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <errno.h>
#include <string.h>
#include "tee_client_api.h"

#define SECSTORAGE_DEMO_WRITEBUFF       "1234567890abcdef"
#define SECSTORAGE_DEMO_PATH            "/data/01.txt"
//#define SECSTORAGE_DEMO_PATH            "/data/vm03_01.txt"
#define SECSTORAGE_DEMO_PATH_NEW        "/data/02.txt"
//#define SECSTORAGE_DEMO_PATH_NEW        "/data/vm03_02.txt"
#define SECSTORAGE_DEMO_MODE_WRITE      (TEE_DATA_FLAG_ACCESS_WRITE | TEE_DATA_FLAG_CREATE)
#define SECSTORAGE_DEMO_MODE_TRUNCATE   (TEE_DATA_FLAG_ACCESS_WRITE \
                                         | TEE_DATA_FLAG_ACCESS_READ \
                                         | TEE_DATA_FLAG_ACCESS_WRITE_META)
#define SECSTORAGE_DEMO_BUF_SIZE            128
#define SECSTORAGE_DEMO_TRUNCATE_BUFF_SIZE  8
#define SECSTORAGE_DEMO_TRUNCATE_OFFSET     4
#define FILE_SEEK_SET                       0

#define AES_KEY_SIZE                        256

#define SECSTORAGE_DEMO_TA_PATH         "/data/9cb38838-2766-42be-8b7b-0d184a996066.sec"

static const TEEC_UUID Secstorage_Demo_uuid = {
    0x9cb38838, 0x2766, 0x42be,
    { 0x8b, 0x7b, 0x0d, 0x18, 0x4a, 0x99, 0x60, 0x66 }
};

TEEC_Context g_context;
TEEC_Session g_session;

enum {
    CMD_SECSTORAGE_CREATE_FILE = 0x1,
    CMD_SECSTORAGE_READ_FILE,
    CMD_SECSTORAGE_DELETE_FILE,
    CMD_SECSTORAGE_WRITE_FILE,
    CMD_SECSTORAGE_RENAME_FILE,
    CMD_SECSTORAGE_TRUNCATE_FILE,
    CMD_SECSTORAGE_SEEK_FILE,
    CMD_SECSTORAGE_TRANSIENT_AES_KEY_FILE = 0x10,
};

// for trusted storage api
#define SECURE_STORAGE_INVALID_FD   0xffffffff

enum DataFlagConstants {
    TEE_DATA_FLAG_ACCESS_READ       = 0x00000001,
    TEE_DATA_FLAG_ACCESS_WRITE      = 0x00000002,
    TEE_DATA_FLAG_ACCESS_WRITE_META = 0x00000004,
    TEE_DATA_FLAG_SHARE_READ        = 0x00000010,
    TEE_DATA_FLAG_SHARE_WRITE       = 0x00000020,
    TEE_DATA_FLAG_CREATE            = 0x00000200,
    TEE_DATA_FLAG_EXCLUSIVE         = 0x00000400,
    TEE_DATA_FLAG_OVERWRITE         = 0x00000400,
    TEE_DATA_FLAG_AES256            = 0x10000400,
    TEE_DATA_FLAG_OPEN_AESC         = 0x20000400,
};

static TEEC_Result TeecInit(void)
{
    TEEC_Operation operation;
    TEEC_Result result;
    uint32_t origin;

    result = TEEC_InitializeContext(NULL, &g_context);
    if (result != TEEC_SUCCESS) {
        TEEC_Error("teec initial failed");
        return result;
    }

    /* pass TA's FULLPATH to TEE, then OpenSession. */
    /* CA MUST use the TEEC_LOGIN_IDENTIFY mode to login. */
    operation.started = 1;
    operation.paramTypes = TEEC_PARAM_TYPES(
        TEEC_NONE,
        TEEC_NONE,
        TEEC_MEMREF_TEMP_INPUT,
        TEEC_MEMREF_TEMP_INPUT);
    g_context.ta_path = SECSTORAGE_DEMO_TA_PATH;

    result = TEEC_OpenSession(&g_context, &g_session, &Secstorage_Demo_uuid, TEEC_LOGIN_IDENTIFY, NULL, &operation, &origin);
    if (result != TEEC_SUCCESS) {
        printf("open session failed: result:%x orgin: %u.\n", (int)result, origin);
        TEEC_FinalizeContext(&g_context);
        return result;
    }

    TEEC_Debug("teec init OK.");
    return result;
}

static void TeecClose(void)
{
    TEEC_CloseSession(&g_session);
    TEEC_FinalizeContext(&g_context);
}

static TEEC_Result SecstorageCreateFile(char *path, uint32_t mode,
                                        char *msg, size_t msgLen)
{
    TEEC_Operation operation;
    TEEC_Result ret;
    uint32_t origin;

    printf("SEC_STORAGE DEMO CREATE FILE is running.\n");

    if ((mode & TEE_DATA_FLAG_CREATE) && (mode & TEE_DATA_FLAG_EXCLUSIVE)) {
        printf("CREATE & EXCLUSIVE can't be concurrence.\n");
        return TEEC_ERROR_BAD_PARAMETERS;
    }

    operation.started = 1;
    operation.paramTypes = TEEC_PARAM_TYPES(
        TEEC_MEMREF_TEMP_INPUT,
        TEEC_VALUE_INPUT,
        TEEC_MEMREF_TEMP_INPUT,
        TEEC_VALUE_OUTPUT
    );
    operation.params[0].tmpref.buffer = (void *)path;
    operation.params[0].tmpref.size = strlen(path);
    operation.params[1].value.a = mode;
    operation.params[2].tmpref.buffer = (void *)msg;
    operation.params[2].tmpref.size = (uint32_t)msgLen;
    operation.params[3].value.a = SECURE_STORAGE_INVALID_FD;

    ret = TEEC_InvokeCommand(&g_session, CMD_SECSTORAGE_CREATE_FILE, &operation, &origin);
    if (ret) {
        printf("TEE create file failed, ret=%x, origin=%x\n", ret, origin);
        return ret;
    }
    printf("secstorage create file success: fd=%d\n", operation.params[3].value.a);

    return TEEC_SUCCESS;
}

static TEEC_Result SecstorageReadFile(char *path, uint32_t mode,
                                      uint8_t *readBuff, size_t *readLen)
{
    TEEC_Operation operation;
    TEEC_Result ret;
    uint32_t origin;

    printf("SEC_STORAGE DEMO READ FILE is running\n");

    operation.started = 1;
    operation.paramTypes = TEEC_PARAM_TYPES(
        TEEC_MEMREF_TEMP_INPUT,
        TEEC_VALUE_INPUT,
        TEEC_MEMREF_TEMP_OUTPUT,
        TEEC_VALUE_OUTPUT
    );
    operation.params[0].tmpref.buffer = (void *)path;
    operation.params[0].tmpref.size = strlen(path);
    operation.params[1].value.a = mode;
    operation.params[2].tmpref.buffer = (void *)readBuff;
    operation.params[2].tmpref.size = (uint32_t)(*readLen);
    operation.params[3].value.a = SECURE_STORAGE_INVALID_FD;
    
    ret = TEEC_InvokeCommand(&g_session, CMD_SECSTORAGE_READ_FILE, &operation, &origin);
    if (ret) {
        printf("read file failed. ret=%x, origin=%x\n", ret, origin);
        return ret;
    }
    *readLen = operation.params[2].tmpref.size;
    printf("secstorage read file success: fd=%d, read count=%zu.\n", operation.params[3].value.a, *readLen);

    return TEEC_SUCCESS;
}

static TEEC_Result SecstorageDeleteFile(char *path, uint32_t mode)
{
    TEEC_Operation operation;
    TEEC_Result ret;
    uint32_t origin;

    printf("SEC_STORAGE DEMO DELETE FILE is running.\n");

    operation.started = 1;
    operation.paramTypes = TEEC_PARAM_TYPES(
        TEEC_MEMREF_TEMP_INPUT,
        TEEC_VALUE_INPUT,
        TEEC_NONE,
        TEEC_NONE
    );
    operation.params[0].tmpref.buffer = (void *)path;
    operation.params[0].tmpref.size = strlen(path);
    operation.params[1].value.a = mode;

    ret = TEEC_InvokeCommand(&g_session, CMD_SECSTORAGE_DELETE_FILE, &operation, &origin);
    if (ret) {
        printf("delete file, ret=%x, origin=%x\n", ret, origin);
        return ret;
    }

    printf("secstorage delete file success.\n");
    return TEEC_SUCCESS;
}

static TEEC_Result SecstorageFileTest(void)
{
    TEEC_Result ret;
    size_t initialDataLen, readLen;
    char *initialDataBuff = SECSTORAGE_DEMO_WRITEBUFF;
    char readBuff[SECSTORAGE_DEMO_BUF_SIZE];

    initialDataLen = strlen(initialDataBuff);
    ret = SecstorageCreateFile(SECSTORAGE_DEMO_PATH, TEE_DATA_FLAG_EXCLUSIVE, initialDataBuff, initialDataLen);
    if (ret) {
        printf("secstorage create file failed\n");
        return TEEC_FAIL;
    }

    readLen = sizeof(readBuff);
    ret = SecstorageReadFile(SECSTORAGE_DEMO_PATH, TEE_DATA_FLAG_ACCESS_READ, readBuff, &readLen);
    if (ret) {
        printf("secstorage read file failed\n");
    }

    SecstorageDeleteFile(SECSTORAGE_DEMO_PATH, TEE_DATA_FLAG_ACCESS_WRITE_META);

    return ret;
}

static TEEC_Result SecstorageWriteFile(char *path, uint32_t mode, char *writeBuff, size_t writeSize)
{
    TEEC_Operation operation;
    TEEC_Result result;
    uint32_t origin;

    printf("SEC_STORAGE DEMO WRITE FILE is running.\n");

    /* First, check init is ok or not */
    if ((g_context.fd == 0) || (g_session.session_id == 0)) {
        TEEC_Error("SEC_STORAGE DEMO WRITE FILE failed, please init Storage Service.\n");
        return  TEEC_ERROR_BAD_STATE;
    }

    /* Then, Invoke Command */
    operation.started = 1;
    operation.cancel_flag = 0;
    operation.paramTypes = TEEC_PARAM_TYPES(
        TEEC_MEMREF_TEMP_INPUT,
        TEEC_VALUE_INPUT,
        TEEC_MEMREF_TEMP_INPUT,
        TEEC_VALUE_OUTPUT
    );
    operation.params[0].tmpref.buffer = path;
    operation.params[0].tmpref.size = strlen(path);
    operation.params[1].value.a = mode;
    operation.params[2].tmpref.buffer = writeBuff;
    operation.params[2].tmpref.size = strlen(writeBuff);
    operation.params[3].value.a = SECURE_STORAGE_INVALID_FD;

    result = TEEC_InvokeCommand(&g_session, CMD_SECSTORAGE_WRITE_FILE, &operation, &origin);
    if (result) {
        TEEC_Error("writefile failed:0x%x, origin:%u.\n", result, origin);
        return result;
    }

    printf("secstorage write file success: fd=%d.\n", operation.params[3].value.a);

    return TEEC_SUCCESS;
}

static TEEC_Result SecstorageRenameFile(char *path, char *new_path, uint32_t mode)
{
    TEEC_Operation operation;
    TEEC_Result result;
    uint32_t origin;

    printf("SEC_STORAGE DEMO RENAME FILE is running\n");

    memset(&operation, 0, sizeof(operation));
    operation.started = 1;
    operation.paramTypes = TEEC_PARAM_TYPES(
        TEEC_MEMREF_TEMP_INPUT,
        TEEC_VALUE_INPUT,
        TEEC_MEMREF_TEMP_INPUT,
        TEEC_VALUE_OUTPUT
    );
    operation.params[0].tmpref.buffer = path;
    operation.params[0].tmpref.size = strlen(path);
    operation.params[1].value.a = mode;
    operation.params[2].tmpref.buffer = new_path; 
    operation.params[2].tmpref.size = strlen(new_path);
    operation.params[3].value.a = SECURE_STORAGE_INVALID_FD;
     
    result = TEEC_InvokeCommand(&g_session, CMD_SECSTORAGE_RENAME_FILE, &operation, &origin);
    if (result) {
        TEEC_Error("reanem file failed: 0x%x, origin=%u\n", result, origin);
        return result;
    }

    printf("secstorage rename file success: fd=%d.\n", operation.params[3].value.a);

    return TEEC_SUCCESS;
}

static TEEC_Result SecstorageTruncateFile(char *path, uint32_t mode, size_t truncateSize)
{
    TEEC_Operation operation;
    TEEC_Result result;
    uint32_t origin = 0;

    printf("SEC_STORAGE DEMO TRUNCATE FILE is running.\n");

    memset(&operation, 0, sizeof(operation));
    operation.started = 1;
    operation.paramTypes = TEEC_PARAM_TYPES(
        TEEC_MEMREF_TEMP_INPUT,
        TEEC_VALUE_INPUT,
        TEEC_VALUE_INPUT,
        TEEC_VALUE_OUTPUT
    );
    operation.params[0].tmpref.buffer = path;
    operation.params[0].tmpref.size = strlen(path);
    operation.params[1].value.a = mode;
    operation.params[2].value.a = truncateSize;
    operation.params[3].value.a = SECURE_STORAGE_INVALID_FD;

    result = TEEC_InvokeCommand(&g_session, CMD_SECSTORAGE_TRUNCATE_FILE, &operation, &origin);
    if (result) {
        TEEC_Error("truncate file failed:0x%x, origin:%u.\n", result, origin);
        return result;
    }

    printf("secstorage truncate file success: fd=%d.\n", operation.params[3].value.a);

    return TEEC_SUCCESS;
}

static TEEC_Result SecstorageSeekFile(char *path, uint32_t mode, int32_t offset, int32_t whence)
{
    TEEC_Operation operation;
    TEEC_Result result;
    uint32_t origin;

    printf("SEC_STORAGE DEMO SEEK FILE is running.\n");

    memset(&operation, 0, sizeof(operation));
    operation.started = 1;
    operation.paramTypes = TEEC_PARAM_TYPES(
        TEEC_MEMREF_TEMP_INPUT,
        TEEC_VALUE_INPUT,
        TEEC_VALUE_INPUT,
        TEEC_VALUE_INPUT
    );
    operation.params[0].tmpref.buffer = path;
    operation.params[0].tmpref.size = strlen(path);
    operation.params[1].value.a = mode;
    operation.params[2].value.a = offset;
    operation.params[3].value.a = whence;

    result = TEEC_InvokeCommand(&g_session, CMD_SECSTORAGE_SEEK_FILE, &operation, &origin);
    if (result) {
        TEEC_Error("seek file failed:0x%x, origin:%u.\n", result, origin);
        return result;
    }

    printf("secstorage seek file success: fd=%d.\n", operation.params[3].value.a);

    return TEEC_SUCCESS;
}

static TEEC_Result SecstorageTransientAESkey(uint32_t keySize)
{
    TEEC_Operation operation;
    TEEC_Result result;
    uint32_t origin;

    printf("SEC_STORAGE DEMO TRANSIENT AES KEY is running.\n");

    operation.paramTypes = TEEC_PARAM_TYPES(
        TEEC_VALUE_INPUT,
        TEEC_NONE,
        TEEC_NONE,
        TEEC_NONE
    );
    operation.params[0].value.a = keySize;

    result = TEEC_InvokeCommand(&g_session, CMD_SECSTORAGE_TRANSIENT_AES_KEY_FILE, &operation, &origin);
    if (result) {
        TEEC_Error("transient aes key failed:0x%x, origin:%u.\n", result, origin);
        return result;
    }

    printf("secstorage transient aes key success.\n");

    return TEEC_SUCCESS;
}

int main(void)
{
    char *initalDataBuff = SECSTORAGE_DEMO_WRITEBUFF;
    char *writeBuff = SECSTORAGE_DEMO_WRITEBUFF;
    size_t initialDataSize;
    TEEC_Result ret;

    ret = TeecInit();
    if (ret) {
        printf("TeecInit failed\n");
        return -1;
    }

    ret = SecstorageFileTest();
    if (ret)
        goto exit;
//SecstorageDeleteFile(SECSTORAGE_DEMO_PATH_NEW, TEE_DATA_FLAG_ACCESS_WRITE_META);
    ret = SecstorageWriteFile(SECSTORAGE_DEMO_PATH, SECSTORAGE_DEMO_MODE_WRITE,
        writeBuff, strlen(writeBuff));
    if (ret) {
        printf("secstorage write file failed\n");
        SecstorageDeleteFile(SECSTORAGE_DEMO_PATH, TEE_DATA_FLAG_ACCESS_WRITE_META);
        goto exit;
    }
sleep(5);
    ret = SecstorageRenameFile(SECSTORAGE_DEMO_PATH, SECSTORAGE_DEMO_PATH_NEW, TEE_DATA_FLAG_ACCESS_WRITE_META);
    if (ret) {
        printf("secstorage rename file failed\n");
        SecstorageDeleteFile(SECSTORAGE_DEMO_PATH, TEE_DATA_FLAG_ACCESS_WRITE_META);
        goto exit;
    }

    ret = SecstorageTruncateFile(SECSTORAGE_DEMO_PATH_NEW, SECSTORAGE_DEMO_MODE_TRUNCATE, SECSTORAGE_DEMO_TRUNCATE_BUFF_SIZE);
    if (ret) {
        printf("secstorage truncate file failed!\n");
        goto delete;
    }

    ret = SecstorageSeekFile(SECSTORAGE_DEMO_PATH_NEW, TEE_DATA_FLAG_SHARE_WRITE, SECSTORAGE_DEMO_TRUNCATE_OFFSET, FILE_SEEK_SET);
    if (ret) {
        printf("secstorage seek file failed!\n");
        goto delete;
    }

    ret = SecstorageTransientAESkey(AES_KEY_SIZE);
    if (ret) {
        printf("secstorage operate transient AES key Failed!\n");
    }

delete:
    SecstorageDeleteFile(SECSTORAGE_DEMO_PATH_NEW, TEE_DATA_FLAG_ACCESS_WRITE_META);

exit:
    TeecClose();
    return ret == TEEC_SUCCESS ? 0 : -1;
}
