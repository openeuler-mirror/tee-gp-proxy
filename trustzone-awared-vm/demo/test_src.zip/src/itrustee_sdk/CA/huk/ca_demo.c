/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2020-2020. All rights reserved.
 * Licensed under the Mulan PSL v2.
 * You can use this software according to the terms and conditions of the Mulan PSL v2.
 * You may obtain a copy of Mulan PSL v2 at:
 *     http://license.coscl.org.cn/MulanPSL2
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY OR FIT FOR A PARTICULAR
 * PURPOSE.
 * See the Mulan PSL v2 for more details.
 * Description: C file template for CA
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <errno.h>
#include <string.h>
#include "tee_client_api.h"

#define VERSION_BUFFER_SIZE 256
#define OPERATION_START_FLAG 1
#define OUT_BUFF_INDEX 3

static const TEEC_UUID g_demoTemplateUuid = {
    0xe3d37f4a, 0xf24c, 0x48d0, { 0x88, 0x84, 0x3b, 0xdd, 0x6c, 0x44, 0xe9, 0x88 }
};

enum {
    CMD_GET_TA_VERSION = 1,
    CMD_HUK            = 2,
};

#define PRINTF_SIZE 32
void DumpBuff(const char *buffer, size_t bufLen)
{
    size_t i;
    if (buffer == NULL || bufLen == 0) {
        return;
    }

    printf("\n--------------------------------------------------\n");
    printf("bufLen = %zu\n", bufLen);
    if (bufLen > 128) {
    	bufLen = 128;
    }
    for (i = 0; i < bufLen; i++) {
        if (i % PRINTF_SIZE == 0) {
            printf("\n");
        }
        printf("%02x ", *(buffer + i));
    }
    printf("\n--------------------------------------------------\n");
    return;
}

TEEC_Context context = {0};
TEEC_Session session = {0};
TEEC_Result result = 0;
TEEC_Operation operation = {0};
uint32_t origin = 0;

void ta_invoke_cmd(uint32_t salt_len, uint32_t key_len)
{
    TEEC_SharedMemory mem[2];
    mem[0].size = salt_len;
    mem[0].flags = TEEC_MEM_INOUT;
    mem[1].size = key_len;
    mem[1].flags = TEEC_MEM_INOUT;
    result = TEEC_AllocateSharedMemory(&context, &mem[0]);
    if (result) {
        printf("TEEC_AllocateSharedMemory failed\n");
        goto END;
    }
    result = TEEC_AllocateSharedMemory(&context, &mem[1]);
    if (result) {
        printf("TEEC_AllocateSharedMemory failed\n");
        goto END;
    }

    memset(mem[0].buffer, 0, mem[0].size);
    memset(mem[1].buffer, 0, mem[1].size);

    operation.started = OPERATION_START_FLAG;
    operation.paramTypes = TEEC_PARAM_TYPES(TEEC_NONE, TEEC_NONE, TEEC_MEMREF_PARTIAL_INPUT, TEEC_MEMREF_PARTIAL_OUTPUT);
    operation.params[2].memref.parent = &mem[0];
    operation.params[2].memref.size = mem[0].size;
    operation.params[2].memref.offset = 0;
    operation.params[3].memref.parent = &mem[1];
    operation.params[3].memref.size = mem[1].size;
    operation.params[3].memref.offset = 0;

    result = TEEC_InvokeCommand(&session, CMD_HUK, &operation, &origin);
    if (result != TEEC_SUCCESS) {
        printf("invoke failed, codes=0x%x, origin=0x%x\n", result, origin);
        printf("salt_len = %d , key_len = %d \n", salt_len, key_len);
        DumpBuff(mem[1].buffer, mem[1].size);
    } else {
        printf("invoke Succeed\n");
        printf("salt_len = %d , key_len = %d \n", salt_len, key_len);
        DumpBuff(mem[1].buffer, mem[1].size);
    }

END:
    TEEC_ReleaseSharedMemory(&mem[0]);
    TEEC_ReleaseSharedMemory(&mem[1]);
}

int main(void)
{
    TEEC_SharedMemory sharebuf;

    char versionBuf[VERSION_BUFFER_SIZE] = {0};
    unsigned int bufLen = VERSION_BUFFER_SIZE;

    result = TEEC_InitializeContext(NULL, &context);
    if (result != TEEC_SUCCESS) {
        printf("teec initial failed");
        goto cleanup_1;
    }

    /* MUST use TEEC_LOGIN_IDENTIFY method */
    operation.started = OPERATION_START_FLAG;
    operation.paramTypes = TEEC_PARAM_TYPES(TEEC_NONE, TEEC_NONE, TEEC_NONE, TEEC_NONE);

    result = TEEC_OpenSession(
        &context, &session, &g_demoTemplateUuid, TEEC_LOGIN_IDENTIFY, NULL, &operation, &origin);
    if (result != TEEC_SUCCESS) {
        printf("teec open session failed");
        goto cleanup_2;
    }

    uint32_t salt_len[] ={1, 32, 255, 1023};
    uint32_t key_len[] ={64, 16, 32, 255, 4096, 4097};
    for (int i=0; i < 4; i++) {
        ta_invoke_cmd(salt_len[i], key_len[0]);
    }

    salt_len[0]= 64;
    printf("\n");
    for (int i=1; i <= 5; i++) {
        ta_invoke_cmd(salt_len[0], key_len[i]);
    } 

    salt_len[0]= 32;
    printf("\n");
    for (int i=0; i < 2; i++) {
        ta_invoke_cmd(salt_len[0], key_len[0]);
    }

END:
    TEEC_CloseSession(&session);
cleanup_2:
    TEEC_FinalizeContext(&context);
cleanup_1:
    return 0;
}

